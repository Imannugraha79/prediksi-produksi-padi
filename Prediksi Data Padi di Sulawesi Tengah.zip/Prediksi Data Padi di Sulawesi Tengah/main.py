import os
import sys
import subprocess

# ======================================================
# AUTO INSTALL LIBRARY
# ======================================================
def install_and_import(package):
    try:
        __import__(package)
    except ImportError:
        print(f"Library '{package}' belum terpasang.")
        print(f"Menginstal {package}...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", package]
        )

install_and_import("pandas")
install_and_import("matplotlib")

import pandas as pd
import matplotlib.pyplot as plt

# ======================================================
# MEMBACA FILE CSV
# ======================================================
FILE_CSV = "data_regresi_padi.csv"

print("=" * 60)
print("REGRESI LINEAR SEDERHANA")
print("METODE SLIDING WINDOW (SIZE = 3)")
print("=" * 60)

if not os.path.exists(FILE_CSV):
    print(f"\nERROR: File '{FILE_CSV}' tidak ditemukan!")
    input("Tekan Enter untuk keluar...")
    sys.exit()

try:
    df = pd.read_csv(FILE_CSV)
except Exception as e:
    print("Gagal membaca file CSV!")
    print("Error :", e)
    input("Tekan Enter untuk keluar...")
    sys.exit()

# ======================================================
# VALIDASI KOLOM
# ======================================================
required_columns = [
    "Tahun",
    "X",
    "Produksi Padi (Ton) (Y)"
]

for col in required_columns:
    if col not in df.columns:
        print(f"Kolom '{col}' tidak ditemukan!")
        sys.exit()

# ======================================================
# MEMBERSIHKAN DATA
# ======================================================
df = df[df["Tahun"] != "Total"].copy()

df["Tahun"] = df["Tahun"].astype(int)
df["X"] = df["X"].astype(int)
df["Produksi Padi (Ton) (Y)"] = (
    df["Produksi Padi (Ton) (Y)"].astype(float)
)

tahun = df["Tahun"].values
x = df["X"].values
y = df["Produksi Padi (Ton) (Y)"].values

# ======================================================
# MENAMPILKAN DATA
# ======================================================
print("\nDATA HISTORIS")
print("-" * 60)

for i in range(len(df)):
    print(
        f"Tahun {tahun[i]} : "
        f"{y[i]:,.0f} Ton"
    )

# ======================================================
# SLIDING WINDOW
# ======================================================
window_size = 3

hasil_prediksi = []
tahun_prediksi = []

print("\n")
print("=" * 60)
print("HASIL PERHITUNGAN SLIDING WINDOW")
print("=" * 60)

for i in range(len(x) - window_size + 1):

    x_window = x[i:i + window_size]
    y_window = y[i:i + window_size]
    tahun_window = tahun[i:i + window_size]

    n = len(x_window)

    sum_x = sum(x_window)
    sum_y = sum(y_window)
    sum_xy = sum(
        xi * yi for xi, yi in zip(x_window, y_window)
    )
    sum_x2 = sum(
        xi ** 2 for xi in x_window
    )

    penyebut = (
        n * sum_x2 -
        (sum_x ** 2)
    )

    if penyebut == 0:
        continue

    b = (
        (n * sum_xy) -
        (sum_x * sum_y)
    ) / penyebut

    a = (
        sum_y -
        b * sum_x
    ) / n

    x_target = x_window[-1] + 1
    target_tahun = tahun_window[-1] + 1

    y_pred = a + b * x_target

    hasil_prediksi.append(y_pred)
    tahun_prediksi.append(target_tahun)

    print(f"\nJendela {i+1}")
    print(
        f"Data : "
        f"{tahun_window[0]} - {tahun_window[-1]}"
    )
    print(
        f"Persamaan : "
        f"Y = {a:.2f} + ({b:.2f})X"
    )
    print(
        f"Prediksi Tahun {target_tahun}"
    )
    print(
        f"Hasil = {y_pred:,.2f} Ton"
    )

# ======================================================
# HASIL AKHIR
# ======================================================
prediksi_2026 = hasil_prediksi[-1]

print("\n")
print("=" * 60)
print("HASIL PREDIKSI AKHIR")
print("=" * 60)

print(
    f"Prediksi Produksi Padi Tahun 2026 = "
    f"{prediksi_2026:,.2f} Ton"
)

# ======================================================
# VISUALISASI
# ======================================================
plt.figure(figsize=(10, 6))

# Data aktual
plt.plot(
    tahun,
    y,
    marker="o",
    linewidth=2,
    label="Data Aktual"
)

# Prediksi Sliding Window
plt.plot(
    tahun_prediksi,
    hasil_prediksi,
    marker="s",
    linestyle="--",
    linewidth=2,
    label="Prediksi Sliding Window"
)

# Titik prediksi utama
plt.scatter(
    tahun_prediksi[-1],
    hasil_prediksi[-1],
    s=200,
    marker="^",
    label=(
        f"Prediksi 2026\n"
        f"{hasil_prediksi[-1]:,.0f} Ton"
    )
)

plt.title(
    "Regresi Linear\n"
)

plt.xlabel("Tahun")
plt.ylabel("Produksi Padi (Ton)")
plt.grid(True)
plt.legend()

plt.tight_layout()

print("\nMenampilkan grafik...")
plt.show()

input("\nProgram selesai. Tekan Enter untuk keluar...")